package nguyenhuuvu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
